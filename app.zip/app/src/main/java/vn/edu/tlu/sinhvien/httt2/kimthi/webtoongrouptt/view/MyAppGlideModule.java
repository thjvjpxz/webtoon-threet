package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.view;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class MyAppGlideModule extends AppGlideModule {
    // Leave class empty. Required for Glide's annotation processor to generate the necessary classes.
}
