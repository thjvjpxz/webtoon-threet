package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.model.models;

public class Chapter {
    private Integer id;
    private String server;
    private String name;
    private String slug;
    private Integer has_report;
    private String report_message;
    private Integer comic_id;
    private String content;
    private Integer story_id;
    private String created_at;
    private String updated_at;
    private String title;
}
