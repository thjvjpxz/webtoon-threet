package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.model.models;

import vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.model.Comic;

public class FollowsStory {
    private Integer id;
    private Integer id_user;
    private Integer id_comic;
    private Integer id_story;
    private Comic story;
    private Chapter chapter;
    private History history;
}
