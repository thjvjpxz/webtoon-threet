package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.model;

public class Image {
    private Integer id;
    private String page;
    private String link;

    public Integer getId() {
        return id;
    }

    public String getPage() {
        return page;
    }

    public String getLink() {
        return link;
    }
}
