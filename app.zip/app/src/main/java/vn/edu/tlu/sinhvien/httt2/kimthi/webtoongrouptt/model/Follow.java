package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.model;


public class Follow {
    private int id;
    private Comic comic;

    public int getId() {
        return id;
    }

    public Comic getComic() {
        return comic;
    }
}
