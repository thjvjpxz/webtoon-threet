package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.model.models;

public class History {
    private Integer user_id;
    private Integer comic_id;
    private String chapterComics_id;
    private Chapter chapter;
}
