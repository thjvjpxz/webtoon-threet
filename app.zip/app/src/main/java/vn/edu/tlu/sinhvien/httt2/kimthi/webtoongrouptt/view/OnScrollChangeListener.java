package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.view;

public interface OnScrollChangeListener {
    void onScrollUp();
    void onScrollDown();
}
