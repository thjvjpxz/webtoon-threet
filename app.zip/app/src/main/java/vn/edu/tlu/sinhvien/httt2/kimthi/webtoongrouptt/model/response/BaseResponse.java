package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.model.response;

public class BaseResponse {
    private String status;
    private String message;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }
}
