package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.view.activity;

public interface CommentInterface {
    void likeComment(String commentId);
    void dislikeComment(String commentId);
    void reportComment(String commentId);
}
