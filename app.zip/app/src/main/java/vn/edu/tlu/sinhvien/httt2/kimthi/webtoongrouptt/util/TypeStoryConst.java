package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.util;

public class TypeStoryConst {
    public static final int TYPE_HOT = 0;
    public static final int TYPE_COMPLETED = 1;
    public static final int TYPE_CONVERT = 2;
    public static final int TYPE_TRANSLATION = 3;

}
