package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.model;

public class Level {
    int id;
    String level;
    String image;
    String style;

    public int getId() {
        return id;
    }

    public String getLevel() {
        return level;
    }

    public String getImage() {
        return image;
    }

    public String getStyle() {
        return style;
    }
}
