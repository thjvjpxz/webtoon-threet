package vn.edu.tlu.sinhvien.httt2.kimthi.webtoongrouptt.model.request;

public class FollowRequest {
    String id;
    String type;

    public FollowRequest(String id, String type) {
        this.id = id;
        this.type = type;
    }
}
